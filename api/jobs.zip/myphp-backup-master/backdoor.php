<a href="myphp-backup.php">For Backup</a>
<a href="myphp-empty.php">For Empty</a>
<a href="myphp-drop.php">For Drop</a>