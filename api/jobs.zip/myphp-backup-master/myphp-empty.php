<?php
$con = mysql_connect('localhost','root','');
 
if (!$con) die("Can't connect to database!");
 
mysql_select_db('dailymet_metrowatch');
 
$res = mysql_query('SHOW TABLES', $con);
 
while ($row = mysql_fetch_array($res, MYSQL_NUM))
{
   $res2 = mysql_query("TRUNCATE TABLE `$row[0]`", $con);
}


?>